using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn
{
    public float delay;
    public string type;
    public int point;
}
